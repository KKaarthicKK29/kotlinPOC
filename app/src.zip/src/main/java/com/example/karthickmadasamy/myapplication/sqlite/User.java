package com.example.karthickmadasamy.myapplication.sqlite;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import com.example.karthickmadasamy.myapplication.models.FeederModel;
import com.example.karthickmadasamy.myapplication.models.Rows;

import java.util.List;

/**
 * Created by alahammad on 10/2/17.
 */

@Entity(tableName = "users")
public class User {
    @PrimaryKey(autoGenerate = true)
    private int uid;

    public String getFeederRows() {
        return feederRows;
    }

    public void setFeederRows(String feederRows) {
        this.feederRows = feederRows;
    }

    @ColumnInfo(name = "rows")
    private String feederRows;

   // @ColumnInfo(name = "last_name")
   // private String lastName;

    public User(String feederRows) {
        this.feederRows = feederRows;
        //this.lastName = lastName;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }



    /*public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }*/
}
