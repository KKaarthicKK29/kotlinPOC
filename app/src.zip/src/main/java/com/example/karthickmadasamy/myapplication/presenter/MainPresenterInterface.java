package com.example.karthickmadasamy.myapplication.presenter;

/**
 * Created by Karthick.Madasamy on 12/4/2019.
 */

public interface MainPresenterInterface {
    void getRows();
}
