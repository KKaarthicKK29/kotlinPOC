package com.example.karthickmadasamy.myapplication.sqlite;

import java.util.List;



public interface DatabaseCallback {

    void onUsersLoaded(List<User> users);

    void onUserDeleted();

    void onUserAdded();

    void onDataNotAvailable();

    void onUserUpdated();
}
